/* ----------------------------
/*  Name: strand
    Author: tharsiha
    Version: 1
/* -------------------------- */